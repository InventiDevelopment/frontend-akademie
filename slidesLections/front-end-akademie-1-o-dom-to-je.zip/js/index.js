/*


const payments = document.querySelectorAll(".payment");

const payments_live = document.getElementsByClassName("payment");

console.log(payments);

*/

/*payments.forEach((payment) => {
  
  console.log(payment);
  
});*/

const payment_list = document.querySelector(".payments-list");

const new_payment = document.createElement("li");
new_payment.setAttribute("class", "payment");
new_payment.innerHTML = "EUR | iTunes platba | 3 €";

payment_list.appendChild(new_payment);

console.log(payments);
console.log(payments_live);


/*
const buttonAdd = document.querySelector(".button-add");
buttonAdd.addEventListener("click", (e) => {
  
  alert("clicked");
  
});
*/