/*Vytvoř si pole několika objektů, kde každý objekt bude symbolizovat platbu a bude obsahovat atributy typ účtu (EUR, CZK), popis útraty a číselnou částku*/

const lide = [
  {
    "name": "payment1",
    "type": "CZK",
    "description": "Payment info",
    "value": 30000
  },
  {
    "name": "payment2",
    "type": "CZK",
    "description": "Payment info",
    "value": 25000
  },
  {
    "name": "payment3",
    "type": "EUR",
    "description": "Payment info",
    "value": 54000
  },

  {
    "name": "payment4",
    "type": "EUR",
    "description": "Payment info",
    "value": 34000
  },
];


const help = ((a,b)=>{
    return a +''+ b;
}); 

/*Projděte pole objektů pomocí forEach a přidejte každému objektu nový atribut “castkaPrint”, který bude příkazem return vracet částku a symbol měny.*/
lide.forEach((item) => {
item.castkaPrint = help(item.value,item.type); 
}); 

console.log(lide);