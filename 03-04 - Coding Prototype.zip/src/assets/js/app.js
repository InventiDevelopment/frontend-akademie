// import any 3rd party or custom libraries here
import moment from 'moment'
import helpers from './helperPlugins'
import pay from './addPayment'
import del from './deletePayment'
import save from './save'



window.moment = moment
// initialize helper plugins
helpers.toggle()



